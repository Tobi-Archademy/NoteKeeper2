package com.jwhh.notekeeper

const val NOTE_POSITION = "NOTE_POSITION"
const val POSITION_NOT_SET = -1